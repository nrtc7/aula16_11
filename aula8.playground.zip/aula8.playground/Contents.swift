func average(notes: [Float]) -> Float {
    var sum: Float = 0.0
    for note in notes {
        sum += note
    }
    return sum / Float(notes.count)
}

let result = average(notes: [8, 5, 5, 8])

func verifyAverage(with average: Float) -> String? {
    if average >= 0 && average <= 2 {
        return "Reprovado"
    }
    if average > 2 && average <= 4 {
        return "Ficou de Recuperação"
    }
    if average > 4 && average <= 6 {
        return "Ficou na Media"
    }
    if average > 6 && average <= 10 {
        return "Aprovado"
    }
    return nil
}

let status = verifyAverage(with: result)!
print(status)

//1 - What are valid ways to call the following function? (Choose 2)
//func fillTank(with fuelType: String, amount: Int = 50) {
//
//}
//
//a) fillTank()
//b) fillTank(with: "diesel", amount: 25) X
//c) fillTank(amount: 95)
//d) fillTank(with: “diesel") X
